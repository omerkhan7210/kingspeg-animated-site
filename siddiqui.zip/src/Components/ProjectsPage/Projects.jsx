import React from 'react'
import {Portfolio} from './Portfolio'

 const Projects = () => {
  return (
    <Portfolio/>
  )
}
export default Projects
